# HPAS BPMN 分层图

主图保留 P01–P08 的具体任务。9 个事件分支在主图中显示为带“+”标记的折叠子流程；每个子流程的任务和泳道都放在独立 BPMN 图层中，可在 Camunda Modeler 中下钻查看。

| 子流程 | 名称 | 下钻图层中的泳道 |
| --- | --- | --- |
| SP03B | P03B Appointment changes | Outpatient Bookings Team |
| SP09 | P09 Manage treatment changes | Clinical Team、Consultants、Finance Team |
| SP10 | P10 Cancellation, refusal and no-shows | Call Handling Team、Finance Team、Consultants、Clinical Team |
| SP11 | P11 Refunds and fund transfers | Finance Team |
| SP12 | P12 Patient enquiries | Call Handling Team、Finance Team、Clinical Nurse Specialist Team |
| SP13 | P13 Clinic letters | Consultants、Patient Pathway Coordinators、Medical Secretaries、Consultants - letter preparation |
| SP14 | P14 Follow-up appointments | Outpatient Bookings Team、Patient Pathway Coordinators |
| SP15 | P15 Monitoring and reports | Patient Pathway Coordinators、Administrative Management Team |
| SP16 | P16 Access, audit and downtime | Administrative Management Team |

打开 [hospital-patient-pathway.bpmn](hospital-patient-pathway.bpmn)，在主图点击折叠子流程的“+”或下钻入口查看内部任务和泳道，再沿面包屑返回主图。事件触发、非中断行为、表单绑定和 Java Job Worker 类型保持在同一流程定义中。

## 文件

- `hospital-patient-pathway.bpmn`：主图及 9 个可下钻的子流程图层。
- `hospital-patient-pathway-preview.svg`、`overview.png`：折叠后的主图预览。
- `forms/`：37 个 Camunda Form。
- `java/`：Spring Boot Java Job Worker 项目。
- `build_redesign.py`、`validate_bundle.py`：生成 BPMN 并检查 BPMN、泳道、表单、Worker 和图层的对应关系。

P01–P08 的人工作业仍引用原来的 37 个表单；55 种 Java Worker 类型保持与 BPMN 中的任务类型一致。分支内部流程、触发事件和泳道也保留在原事件子流程中。

## 重建和校验

在项目根目录运行：

```powershell
python redesign\build_redesign.py
python redesign\validate_bundle.py
python hpas-build\check_semantics.py
python hpas-build\render_preview.py redesign\hospital-patient-pathway.bpmn redesign\hospital-patient-pathway-preview.svg
```

## 验证记录

- BPMN lint：0 个错误；32 条 `fake-join` 警告来自多个合法流入的合流节点建议。
- Camunda 8.9 部署成功（`Process_HPAS` v4）。
- 对活动实例发送预约变更消息后，SP03B 事件子流程创建了 `hpas-sp03b-search-slot` Job；无 incident。验证实例已取消，测试集群已停止。
